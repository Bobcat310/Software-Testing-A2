# My Login Page
<br />

https://github.com/jagadeeshpj/flipr_lms


## login page <br />
i had created this responsive website using html,css,javascript.  <br />
i had used remotetype database from https://www.freesqldatabase.com and mysql workbench 8.0 ce.
 <br />
  <br />
   <br />

 <br />
 
 # Screenshots
 
 ## DESKTOP VIEW
 ![Screenshot (714)](https://user-images.githubusercontent.com/87519174/134881804-17d92b99-df57-47ed-ad21-08c14b4ffe37.png)
<br />
## MOBILE VIEW
<img src="https://user-images.githubusercontent.com/87519174/134882631-3caeea38-3fb4-43bf-b4ac-cfdc207ae4b8.jpeg" width="400" height="790">

 
 
 ## Front End
 <br />
HTML & CSS (using SCSS)   <br />

JavaScript   <br />
php  <br />  <br />  <br />

## Back End  <br />
remote type databasehttps://www.freesqldatabase.com/)  <br />
MySQL  <br />
 <br />  <br />

# Deployment  <br />
 <br />
Heroku  <br />
Github Actions

 <br />  <br />

## Installation & Running
## System Requirements

## For Server Side Setup / Development Environment:   <br />

Google Chrome  <br />
Git: Our project uses Git as a version control system.  <br />
Visual Studio Code  <br />
sublimeText  <br />  <br />

## For running on the Client Side:
 <br />
A modern browser that supports localStorage & Single Page Applications:  <br />
Google Chrome <br />
Mozilla Firefox <br />
Microsoft Edge (Blink Engine)
 <br />
